sudo docker stop app
sudo docker rm app
